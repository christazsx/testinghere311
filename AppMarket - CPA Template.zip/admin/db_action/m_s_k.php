<?php
$lI = "Yourdomain.com";
?>